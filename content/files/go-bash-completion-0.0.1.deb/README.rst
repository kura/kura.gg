Installation
============

Debian/Ubuntu
-------------

* cp go /etc/bash_completion.d/go
* . ~/bashrc

License
=======

This software is licensed using the MIT License.
The license is provided in the `source code repository
<https://github.com/kura/go-bash-completion/blob/master/LICENSE>`_.
